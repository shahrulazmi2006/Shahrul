<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Home | Kafesta</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <h1>Kafesta Delivery 🍴</h1>
    <nav>
        <a href="index.php" class="active">Home</a>
        <a href="menu.php">Menu</a>
        <a href="cart.php">Cart</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<div class="home-box">
<h2>Welcome, <?= isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest' ?>!</h2>
<p>Enjoy your favorite meals delivered fast.</p>
<img src="homepic.avif" alt="Food" class="home-img">
<button onclick="window.location='menu.php'">View Menu</button>
</div>
</body>
</html>
