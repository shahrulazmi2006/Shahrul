<?php include("database.php"); session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login | Kafesta</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header><h1>Kafesta Delivery 🍴</h1></header>

<div class="form-box">
<h2>Login</h2>
<form method="post">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="submit" name="login" value="Login">
</form>
<p>No account? <a href="register.php">Register</a></p>
</div>

<?php
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM users WHERE username='$username' AND password='$password'");
    if (mysqli_num_rows($query) == 1) {
        $_SESSION['username'] = $username;
        $_SESSION['cart'] = [];
        header("Location: index.php");
    } else {
        echo "<script>alert('Incorrect Username or Password');</script>";
    }
}
?>
</body>
</html>
