<?php include("database.php"); session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register | Kafesta</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header><h1>Kafesta Delivery 🍴</h1></header>

<div class="form-box">
<h2>Register</h2>
<form method="post">
    <input type="text" name="username" placeholder="Username" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="submit" name="register" value="Register">
</form>
<p>Already have an account? <a href="login.php">Login</a></p>
</div>

<?php
if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $check = mysqli_query($conn, "SELECT * FROM users WHERE username='$username' OR email='$email'");
    if (mysqli_num_rows($check) > 0) {
        echo "<script>alert('Username or Email already exists!');</script>";
    } else {
        mysqli_query($conn, "INSERT INTO users(username, email, password) VALUES('$username','$email','$password')");
        echo "<script>alert('Registration successful!'); window.location='login.php';</script>";
    }
}
?>
</body>
</html>
