<?php
session_start();
include("database.php");

if (isset($_GET['action']) && isset($_GET['food'])) {
    $food = $_GET['food'];
    $username = $_SESSION['username'] ?? 'guest';

    if ($_GET['action'] == 'add') {
        $conn->query("UPDATE cart SET quantity = quantity + 1 WHERE username='$username' AND food_name='$food'");
    } elseif ($_GET['action'] == 'minus') {
        $conn->query("UPDATE cart SET quantity = quantity - 1 WHERE username='$username' AND food_name='$food' AND quantity > 1");
        $conn->query("DELETE FROM cart WHERE username='$username' AND food_name='$food' AND quantity <= 0");
    }
    header("Location: cart.php");
    exit;
}

$username = $_SESSION['username'] ?? 'guest';
$result = $conn->query("SELECT * FROM cart WHERE username='$username'");
$cart = [];
$total = 0;
while ($row = $result->fetch_assoc()) {
    $cart[] = $row;
    $total += $row['price'] * $row['quantity'];
}

if (isset($_POST['order'])) {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $table = $_POST['table'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $notes = $_POST['notes'];

    $items_text = "";
    foreach ($cart as $item) {
        $items_text .= "{$item['food_name']} x {$item['quantity']} (RM " . ($item['price'] * $item['quantity']) . ")\n";
    }

    $stmt = $conn->prepare("INSERT INTO orders (name, phone, table_no, date, time, notes, total, items) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssisssds", $name, $phone, $table, $date, $time, $notes, $total, $items_text);
    $stmt->execute();
    $stmt->close();

    $conn->query("DELETE FROM cart WHERE username='$username'");

    // Redirect to WhatsApp
    $msg = "Hello Kafesta! 👋\nName: $name\nPhone: $phone\nTable: $table\nDate: $date | Time: $time\n\nOrder:\n$items_text\nTotal: RM $total.00\nNotes: $notes";
    $wa = "60199199351";
    echo "<script>window.location='https://wa.me/$wa?text='+encodeURIComponent(`$msg`);</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Cart | Kafesta</title>
<link rel="stylesheet" href="style.css">
<style>
body {
    background-color: #D5F5E3;
    font-family: Arial, sans-serif;
    text-align: center;
    margin: 0;
}
.cart-box, .form-box {
    background-color: #58D68D;
    width: 85%;
    max-width: 900px;
    margin: 30px auto;
    padding: 25px;
    border-radius: 14px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
}
table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
th, td { padding: 10px; border-bottom: 1px solid #145A32; }
th { background-color: #145A32; color: white; }
td a { text-decoration: none; color: #145A32; padding: 5px 8px; background: #D5F5E3; border-radius: 5px; }
td a:hover { background: #145A32; color: white; }
.form-box input, .form-box textarea, .form-box button {
    width: 100%; margin: 8px 0; padding: 10px;
    border-radius: 6px; border: none; background: #E9F7EF;
}
.form-box textarea { height: 90px; }
.form-box button {
    background-color: #145A32; color: white; cursor: pointer; font-weight: bold;
}
.form-box button:hover { background-color: #0E3B23; }
.action-btns { display: flex; gap: 10px; margin-top: 10px; }
.action-btns button { flex: 1; padding: 12px; border: none; border-radius: 8px; }
.back-btn { background: #0E3B23; color: white; }
</style>
</head>
<body>
<header>
<h1>Kafesta Delivery 🍴</h1>
<nav>
    <a href="index.php">Home</a>
    <a href="menu.php">Menu</a>
    <a href="cart.php" class="active">Cart</a>
    <a href="logout.php">Logout</a>
</nav>
</header>

<h2>Your Cart 🛒</h2>

<div class="cart-box">
<?php if (empty($cart)): ?>
<p>Your cart is empty. <a href="menu.php">Go to Menu</a></p>
<?php else: ?>
<table>
<tr><th>Food</th><th>Qty</th><th>Price (RM)</th></tr>
<?php foreach ($cart as $item): ?>
<tr>
<td><?= $item['food_name'] ?></td>
<td>
<a href="?action=minus&food=<?= urlencode($item['food_name']) ?>">➖</a>
<?= $item['quantity'] ?>
<a href="?action=add&food=<?= urlencode($item['food_name']) ?>">➕</a>
</td>
<td><?= $item['price'] * $item['quantity'] ?>.00</td>
</tr>
<?php endforeach; ?>
</table>
<p><strong>Total: RM <?= $total ?>.00</strong></p>
<?php endif; ?>
</div>

<?php if (!empty($cart)): ?>
<div class="form-box">
<h3>Reservation & Customer Details</h3>
<form method="post">
    <input type="text" name="name" placeholder="Your Name" required>
    <input type="text" name="phone" placeholder="Phone Number" required>
    <input type="number" name="table" placeholder="Table Number" required>
    <input type="date" name="date" required>
    <input type="time" name="time" required>
    <textarea name="notes" placeholder="Any special requests..."></textarea>
    <div class="action-btns">
        <button type="submit" name="order">Order via WhatsApp</button>
        <button type="button" class="back-btn" onclick="window.location='menu.php'">Back to Menu</button>
    </div>
</form>
</div>
<?php endif; ?>
</body>
</html>
