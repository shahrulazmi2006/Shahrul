<?php
session_start();
include("database.php");

$username = $_SESSION['username'] ?? 'guest'; 


if (isset($_POST['add'])) {
    $food = $_POST['food'];
    $price = $_POST['price'];

    
    $check = $conn->query("SELECT * FROM cart WHERE username='$username' AND food_name='$food'");
    if ($check->num_rows > 0) {
        $conn->query("UPDATE cart SET quantity = quantity + 1 WHERE username='$username' AND food_name='$food'");
    } else {
        $conn->query("INSERT INTO cart (username, food_name, price, quantity) VALUES ('$username', '$food', '$price', 1)");
    }

    echo "<script>alert('Added to cart!'); window.location='menu.php';</script>";
}

$count_result = $conn->query("SELECT SUM(quantity) AS total_items FROM cart WHERE username='$username'");
$count_row = $count_result->fetch_assoc();
$cart_count = $count_row['total_items'] ?? 0;


$menu = [
    "COFFEE" => [
        ["name" => "A1. Espresso", "price" => 6, "image" =>"image/A1.Espresso.jpg"],
        ["name" => "A2. Americano", "price" => 6, "image" => "image/A2.Americano.jpg"],
        ["name" => "A3. Coffee Latte", "price" => 8, "image" => "image/A3.Coffee Latte.jpg"],
        ["name" => "A4. Vanilla Coffee Latte", "price" => 10, "image" => "image/A4.Vanilla Coffee Latte.jpg"],
        ["name" => "A5. Salted Caramel Coffee Latte", "price" => 10, "image" => "image/A5. Salted Caramel Coffee Latte.jpg"],
        ["name" => "A6. Butterscotch Coffee Latte", "price" => 10, "image" => "image/A6. Butterscotch Coffee Latte.jpg"],
        ["name" => "A7. Hazelnut Coffee Latte", "price" => 10, "image" => "image/A7. Hazelnut Coffee Latte.jpg"],
        ["name" => "A8. Mocha", "price" => 10, "image" => "image/A8. Mocha.jpg"],
        ["name" => "A9. Toffee Latte", "price" => 10, "image" => "image/A9. Toffee Latte.jpg"],
        ["name" => "A10. Spanish Coffee Latte", "price" => 10, "image" => "image/A10. Spanish Coffee Latte.jpg"]
    ],

    "COFFEE FRAPPE" => [
        ["name" => "D1. Coffee Latte Frappe", "price" => 9, "image" => "image/D1. Coffee Latte Frappe.jpg"],
        ["name" => "D2. Vanilla Coffee Frappe", "price" => 11, "image" => "image/D2. Vanilla Coffee Frappe.jpg"],
        ["name" => "D3. Salted Caramel Coffee Frappe", "price" => 11, "image" => "image/D3. Salted Caramel Coffee Frappe.jpg"],
        ["name" => "D4. Butterscotch Coffee Frappe", "price" => 11, "image" => "image/D4. Butterscotch Coffee Frappe.jpg"],
        ["name" => "D5. Hazelnut Coffee Frappe", "price" => 11, "image" => "image/D5. Hazelnut Coffee Frappe.jpg"],
        ["name" => "D6. Mocha Coffee Frappe", "price" => 11, "image" => "image/D6. Mocha Coffee Frappe.jpg"]
    ],

    "MILKY FRAPPE" => [
        ["name" => "E6. Caramel Upside Down Milky Frappe", "price" => 9, "image" => "image/E1. Caramel Upside Down Milky.jpg"],
        ["name" => "E7. Butterscotch Upside Down Milky Frappe", "price" => 9, "image" => "image/E7. Butterscotch Upside Down Milky Frappe.jpg"],
        ["name" => "E8. Strawberry Butterscotch Milky Frappe", "price" => 10, "image" => "image/E8. Strawberry Butterscotch Milky Frappe.jpg"],
        ["name" => "E9. Mango Butterscotch Milky Frappe", "price" => 10, "image" => "image/E9. Mango Butterscotch Milky Frappe.jpg"],
        ["name" => "E10. Matcha Milky Frappe", "price" => 11, "image" => "image/E10. Matcha Milky Frappe.jpg"],
        ["name" => "E11. Matcha Strawberry Milky Frappe", "price" => 13, "image" => "image/E11. Matcha Strawberry Milky Frappe.jpg"],
        ["name" => "E12. Matcha Chocolate Milky Frappe", "price" => 13, "image" => "image/E12. Matcha Chocolate Milky Frappe.jpg"]
    ],

    "CHOCOLATE FRAPPE" => [
        ["name" => "G1. Chocolate Frappe", "price" => 10, "image" => "image/G1. Chocolate Frappe.png"],
        ["name" => "G2. Oreo Crush Frappe", "price" => 11, "image" => "image/G2. Oreo Crush Frappe.jpg"],
        ["name" => "G3. Salted Caramel Chocolate Frappe", "price" => 11, "image" => "image/G3. Salted Caramel Chocolate Frappe.png"],
        ["name" => "G4. Strawberry Chocolate Frappe", "price" => 11, "image" => "image/G4. Strawberry Chocolate Frappe.jpg"],
        ["name" => "G5. Chocolate Mint Frappe", "price" => 11, "image" => "image/G5. Chocolate Mint Frappe.png"],
        ["name" => "G6. Blueberry Yogurt Frappe", "price" => 13, "image" => "image/G6. Blueberyy Yogurt Frappe.png"]
    ],

    "YOGURT FRAPPE" => [
        ["name" => "F1. Strawberry Yogurt Frappe", "price" => 11, "image" => "image/F1. Strawberry Yogurt Frappe.png"],
        ["name" => "F2. Mango Yogurt Frappe", "price" => 11, "image" => "image/F2. Mango Yogurt Frappe.png"],
        ["name" => "F3. Kiwi Yogurt Frappe", "price" => 11, "image" => "image/F3. Kiwi Yogurt Frappe.png"]
    ],

    "MILKY" => [
        ["name" => "E1. Caramel Upside Down Milky", "price" => 8, "image" => "image/E1. Caramel Upside Down Milky.jpg"],
        ["name" => "E2. Butterscotch Upside Down Milky", "price" => 8, "image" => "image/E2. Buttersotch Upside Down Milky.jpg"],
        ["name" => "E3. Strawberry Butterscotch Milky", "price" => 9, "image" => "image/E3. Strawberry Butterscotch Milky.jpg"],
        ["name" => "E4. Mango Butterscotch Milky", "price" => 9, "image" => "image/E4. Mango Butterscotch Milky.jpg"],
        ["name" => "E5. Matcha Latte", "price" => 9, "image" => "image/E5. Matcha Latte.jpg"],
        ["name" => "E13_1. Strawberry Milk", "price" => 8, "image" => "image/E13_1. Strawberry Milk.jpg"]
    ],

    "CHOCOLATE" => [
        ["name" => "B1. Chocolate Drink", "price" => 7, "image" => "image/B1. Chocolate Drink.jpg"],
        ["name" => "B2. Chocolate Mint", "price" => 9, "image" => "image/B2. Chocolate Mint.jpg"]
    ],

    "FRUITY TEA" => [
        ["name" => "C1. Strawberry Tea", "price" => 6, "image" => "image/C1. Strawberry Tea.jpg"],
        ["name" => "C2. Manggo Tea", "price" => 6, "image" => "image/C2. Manggo Tea.jpg"],
        ["name" => "C3. Kiwi Tea", "price" => 6, "image" => "image/C3. Kiwi Tea.jpg"],
        ["name" => "C4. Lemon Tea", "price" => 4, "image" => "image/C4. Lemon Tea.jpg"],
        ["name" => "C5. Matcha Latte", "price" => 9, "image" => "image/C5. Matcha Latte.jpg"]
    ],

    "EVERGREEN" => [
        ["name" => "I1. A&W Float", "price" => 5, "image" => "image/I1. A&W Float.jpg"],
        ["name" => "I2. Honey Lemon", "price" => 4, "image" => "image/I2. Honey Lemon.jpg"],
        ["name" => "I3. Lychee", "price" => 4, "image" => "image/I2. Lychee.jpg"],
        ["name" => "I4. Milo/Vico", "price" => 4, "image" => "image/I4. Milo & Vico.jpg"],
        ["name" => "I5. Teh O", "price" => 3, "image" => "image/I5. Teh O.jpg"]
    ],

    "MOJITO SPARKLING" => [
        ["name" => "H1. Lemon Mojito Sparkling", "price" => 7, "image" => "image/H1. Lemon Mojito Sparkling.jpg"],
        ["name" => "H2. Strawberry Mojito Sparkling", "price" => 8, "image" => "image/H2. Strawberry Mojito Sparkling.jpg"],
        ["name" => "H3. Manggo Mojito Sparkling", "price" => 8, "image" => "image/H3.Manggo Mojito Sparkling.jpg"],
        ["name" => "H4. Kiwi Mojito Sparkling", "price" => 8, "image" => "image/H4. Kiwi Majito Sparkling.jpg"],
        ["name" => "H5. Blue Ocean Mojito Sparkling", "price" => 8, "image" => "image/H5. Blue Ocean Mojito Sparkling.jpg"]
    ],

    "NASI HAINAN" => [
        ["name" => "P1. Nasi Hainan Kosong", "price" => 4.00, "image" => "image/placeholder.jpg"],
        ["name" => "P2. Nasi Hainan Grilled Chicken", "price" => 16.00, "image" => "image/P2. Nasi Hainan Grilled Chicken.jpg"],
        ["name" => "P3. Nasi Hainan Chicken Chop", "price" => 16.00, "image" => "image/P2. Nasi Hainan Chicken Chop.jpg"],
        ["name" => "P5a. Nasi Hainan Kambing Bakar (100g)", "price" => 15.00, "image" => "image/P5a. Nasi Hainan Kambing Bakar (100g).jpg"],
        ["name" => "P5b. Nasi Hainan Kambing Bakar (200g)", "price" => 24.00, "image" => "image/P5b. Nasi Hainan Kambing Bakar (200g).jpg"],
        ["name" => "P6. Nasi Hainan Ayam Goreng", "price" => 9.00, "image" => "image/P6. Nasi Hainan Ayam Goreng.jpg"],
        ["name" => "P7. Nasi Hainan Sotong Raja", "price" => 20.00, "image" => "image/placeholder.jpg"]
    ],
    "NASI GORENG" => [
        ["name" => "P11. Nasi Goreng", "price" => 7.00, "image" => "image/P11.Nasi Goreng.jpg"],
        ["name" => "P12. Nasi Goreng Chicken Gril", "price" => 17.00, "image" => "image/placeholder.jpg"],
        ["name" => "P13. Nasi Goreng Chicken Chop", "price" => 17.00, "image" => "image/placeholder.jpg"],
        ["name" => "P15a. Nasi Goreng Kambing Bakar (100g)", "price" => 17.00, "image" => "image/placeholder.jpg"],
        ["name" => "P15b. Nasi Goreng Kambing Bakar (200g)", "price" => 26.00, "image" => "image/placeholder.jpg"],
        ["name" => "P16. Nasi Goreng Ayam Goreng", "price" => 10.00, "image" => "image/placeholder.jpg"],
        ["name" => "P17. Nasi Goreng Sotong Raja", "price" => 21.00, "image" => "image/placeholder.jpg"]
    ],
    "NASI PUTIH + MASAK LEMAK UDANG" => [
        ["name" => "Q1. Nasi Putih Kosong", "price" => 3.00, "image" => "images/placeholder.jpg"],
        ["name" => "Q2. Nasi Putih+lemak udang 3pcs+Ayam Goreng", "price" => 13.00, "image" => "image/placeholder.jpg"],
        ["name" => "Q5a. Nasi Putih+lemak udang 3pcs+Kambing Bakar (100g)", "price" => 17.00, "image" => "image/placeholder.jpg"],
        ["name" => "Q5b. Nasi Putih+lemak udang 3pcs+Kambing Bakar (200g)", "price" => 26.00, "image" => "image/placeholder.jpg"],
        ["name" => "Q6. Nasi Putih+lemak udang 3pcs+Sotong Raja", "price" => 21.00, "image" => "image/placeholder.jpg"],
        ["name" => "Q7. Nasi Putih+lemak Udang (5pcs)", "price" => 12.00, "image" => "image/placeholder.jpg"],
        ["name" => "Q18. Nasi Putih Ayam Buttermilk", "price" => 16.00, "image" => "image/placeholder.jpg"]
    ],
    "NASI LEMAK" => [
        ["name" => "Q11. Nasi Lemak Biasa", "price" => 5.00, "image" => "image/placeholder.jpg"],
        ["name" => "Q12. Nasi Lemak Grilled Chicken", "price" => 16.00, "image" => "image/placeholder.jpg"],
        ["name" => "Q13. Nasi Lemak Chicken Chop", "price" => 16.00, "image" => "image/placeholder.jpg"],
        ["name" => "Q16. Nasi Lemak Ayam Goreng", "price" => 9.00, "image" => "image/placeholder.jpg"],
        ["name" => "Q17. Nasi Lemak Sotong Raja", "price" => 20.00, "image" => "image/placeholder.jpg"]
    ],
    "SPAGHETTI" => [
        ["name" => "S1. Spaghetti Meatball", "price" => 15.00, "image" => "image/S1. Spaghetti Meatball.jpg"],
        ["name" => "S2. Spaghetti Chicken Chop", "price" => 17.00, "image" => "image/S2. Spaghetti Chicken Chop.jpg"],
        ["name" => "S3. Spaghetti Grilled Chicken", "price" => 17.00, "image" => "image/placeholder.jpg"],
        ["name" => "S4. Chicken Spaghetti", "price" => 11.00, "image" => "image/S4. Chicken Spaghetti.jpg"]
    ],
    "SPAGHETTI AGLIO OLIO" => [
        ["name" => "S6. Aglio Olio Streaky Beef", "price" => 13.00, "image" => "image/S6. Aglio Olio Streaky Beef.jpg"],
        ["name" => "S7. Aglio Olio Pepperoni", "price" => 13.00, "image" => "image/S7. Aglio Olio Pepperoni.jpg"],
        ["name" => "S8. Aglio Olio Prawn", "price" => 15.00, "image" => "image/S8. Aglio Olio Prawn.jpg"],
        ["name" => "S9. Spaghetti Aglio Olio Grilled Chicken", "price" => 17.00, "image" => "image/placeholder.jpg"],
        ["name" => "S11. Spaghetti Buttermilk", "price" => 16.00, "image" => "image/S11. Spaghetti Buttermilk.jpg"]
    ],
    "MAC N CHEESE" => [
        ["name" => "R1. Mac n Cheese Streaky Beef", "price" => 12.00, "image" => "image/R1. Mac n Cheese Streaky Beef.jpg"],
        ["name" => "R2. Mac n Cheese Pepperoni", "price" => 12.00, "image" => "image/R2. Mac n Cheese Pepperoni.jpg"],
        ["name" => "R3. Mac n Cheese Meatball", "price" => 12.00, "image" => "images/placeholder.jpg"]
    ],
    "WESTERN" => [
        ["name" => "T1. Western Chicken Chop", "price" => 15.00, "image" => "image/T1. Western Chicken Chop.jpg"],
        ["name" => "T2. Western Grilled Chicken", "price" => 15.00, "image" => "image/T2. Western Grilled Chicken.jpg"],
        ["name" => "T3. Lamb Chop", "price" => 23.00, "image" => "image/T3. Lamb Chop.jpg"],
        ["name" => "T4. Fish & Chips", "price" => 15.00, "image" => "image/T4. Fish & Chips.jpg"],
        ["name" => "T5. Mix Platter (Grilled Chicken+Lamb Chop+Meatball)", "price" => 24.00, "image" => "image/T5. Mix Platter (Grilled Chicken+Lamb Chop+Meatball.jpg"],
        ["name" => "T6. Black Angus Striploin Steak (200g+)", "price" => 69.00, "image" => "image/placeholder.jpg"]
    ],
    "BURGER" => [
        ["name" => "M1. Beef Cheese Burger", "price" => 12.00, "image" => "image/M1. Beef Cheese Burger.jpg"],
        ["name" => "M2. Double Beef Cheese Burger", "price" => 18.00, "image" => "image/M2. Double Beef Cheese Burger.jpg"],
        ["name" => "M3. Streaky Beef Cheese Burger", "price" => 18.00, "image" => "image/M3. Streaky Beef Chicken Burger.jpg"],
        ["name" => "M4. Ultimate Burger (Beef+Chicken)", "price" => 18.00, "image" => "image/M4. Ultimate Burger (Beef+Chicken).jpg"],
        ["name" => "M5. Crispy Chicken Original Burger", "price" => 11.00, "image" => "image/M5. Crispy Chicken Original Burger.jpg"],
        ["name" => "M6. Crispy Chicken Spicy Burger", "price" => 11.00, "image" => "image/M6. Crispy Chicken Spicy Burger.jpg"],
        ["name" => "M7. Grilled Chicken Burger (GCB)", "price" => 11.00, "image" => "image/M7. Grilled Chicken Burger (GCB).jpg"],
        ["name" => "M8. Korean Spicy Chicken Burger", "price" => 11.00, "image" => "image/M8. Korean Spicy Chicken Burger.jpg"]
    ],
    "WRAP" => [
        ["name" => "N1. Beef Cheese Wrap", "price" => 12.00, "image" => "images/placeholder.jpg"],
        ["name" => "N2. Double Beef Cheese Wrap", "price" => 18.00, "image" => "images/placeholder.jpg"],
        ["name" => "N3. Streaky Beef Cheese Wrap", "price" => 18.00, "image" => "images/placeholder.jpg"],
        ["name" => "N4. Ultimate (Beef+Chicken) Wrap", "price" => 18.00, "image" => "images/placeholder.jpg"],
        ["name" => "N5. Crispy Chicken Original Wrap", "price" => 11.00, "image" => "images/placeholder.jpg"],
        ["name" => "N6. Crispy Chicken Spicy Wrap", "price" => 11.00, "image" => "images/placeholder.jpg"],
        ["name" => "N7. Grilled Chicken Wrap (GCW)", "price" => 11.00, "image" => "images/placeholder.jpg"],
        ["name" => "N8. Korean Spicy Chicken Wrap", "price" => 11.00, "image" => "images/placeholder.jpg"]
    ],
    "SET TALAM CLASSIC(2-3 Orang)" => [
        ["name" => "UA1. SET TALAM CLASSIC Nasi Hainan", "price" => 45.00, "image" => "image/UA1. Set Talam Classic Nasi Hainan.jpg"],
        ["name" => "UA2. SET TALAM CLASSIC Spaghetti", "price" => 47.00, "image" => "image/UA2. Set Talam Classic Spaghetti.jpg"],
        ["name" => "UA4. SET TALAM CLASSIC Mac and Cheese", "price" => 47.00, "image" => "image/placeholder.jpg"]
    ],
    "LAUK MERATAH" => [
        ["name" => "W1. Meratah Kambing Classic (250g)*", "price" => 18.00, "image" => "image/W1. Meratah Kambing Classic (250g).jpg"],
        ["name" => "W2. Meratah Kambing Ultimate (500g)", "price" => 35.00, "image" => "image/W2. Meratah Kambing Ultimate (500g).jpg"],
        ["name" => "W4. Ayam Goreng (Original/Spicy) 1 pc", "price" => 5.00, "image" => "image/W4. Ayam Goreng (Original&Spicy) 1 pc.jpg"],
        ["name" => "W5. Sotong Raja", "price" => 16.00, "image" => "image/W5. Sotong Raja.jpg"]
    ],
    "AN NYOUNG KOREAN" => [
        ["name" => "V1. Drumettes Soy Garlic Sauce (5pcs)", "price" => 16.00, "image" => "image/V1. Drumettes Soy Garlic Sauce (5pcs).jpg"],
        ["name" => "V2. Drumettes Spicy Red Sauce (5pcs)", "price" => 16.00, "image" => "image/V2. Drumettes Spicy Red Sauce (5pcs).jpg"],
        ["name" => "V3. Cheesy Drumettes Spicy (5pcs)", "price" => 16.00, "image" => "image/V3. Cheesy Drumettes Spicy (5pcs).jpg"],
        ["name" => "V4. Ramen with Korean Drumettes Spicy Red Pepper*", "price" => 19.00, "image" => "image/V4. Ramen with Korean Drumettes Spicy Red Pepper.jpg"],
        ["name" => "V5. Ramen with Meatball", "price" => 15.00, "image" => "image/V5. Ramen with Meatball.jpg"],
        ["name" => "V6. Ramen with Grilled Chicken", "price" => 17.00, "image" => "image/V6. Ramen with Grilled Chicken.jpg"],
        ["name" => "V7. Ramen Kosong", "price" => 9.00, "image" => "image/V7. Ramen Kosong.jpg"]
    ],
    "MEATBALL (7pieces)" => [
        ["name" => "R5. Meatball Carbonara", "price" => 10.00, "image" => "image/R5. Meatball Carbonara.jpg"],
        ["name" => "R6. Meatball Bolognese", "price" => 10.00, "image" => "image/R6. Meatball Bolognese.jpg"],
        ["name" => "R7. Meatball Blackpepper", "price" => 10.00, "image" => "images/placeholder.jpg"]
    ],
    "SANTAI" => [
        ["name" => "W3. Bihun Sup Meatball", "price" => 7.00, "image" => "image/W3. Bihun Sup Meatball.jpg"],
        ["name" => "YB1. Dimsum Classic (4Pcs)", "price" => 7.00, "image" => "image/YB1. Dimsum Classic (4Pcs).jpg"],
        ["name" => "YB5. Wantan Classic (5pcs)", "price" => 17.00, "image" => "image/YB5. Wantan Classic (5pcs).jpg"]
    ],
    "KIDS MEAL with LEMON TEA" => [
        ["name" => "Z1. Kids Meal: Nasi Hainan Fried Chicken", "price" => 9.00, "image" => "images/placeholder.jpg"],
        ["name" => "Z3. Kids Meal: Nuggets & Fries", "price" => 9.00, "image" => "images/placeholder.jpg"],
        ["name" => "Z4. Kids Meal: Meatballs & Fries", "price" => 9.00, "image" => "images/placeholder.jpg"]
    ],
    "CHEESE PEASY" => [
        ["name" => "X1. Nacho (100g)", "price" => 7.00, "image" => "image/X1. Nacho (100g).jpg"],
        ["name" => "X3. Nuggets (8pcs)", "price" => 9.00, "image" => "image/X3. Nuggets (8pcs).jpg"],
        ["name" => "X4. Wedges (8-12pcs)", "price" => 9.00, "image" => "image/X4. Wedges (8-12pcs).jpg"],
        ["name" => "X5. Fries", "price" => 8.00, "image" => "image/X5. Fries.jpg"]
    ],
    "ICE CREAM" => [
        ["name" => "K4. 1 Scoop", "price" => 2.00, "image" => "image/K4. 1 Scoop.jpg"],
        ["name" => "K5. 3 Scoops", "price" => 5.00, "image" => "image/K5. 3 Scoops.jpg"]
    ],
    "CAKE" => [
        ["name" => "Carrot Cake", "price" => 13.00, "image" => "image/Carrot Cake.jpg"],
        ["name" => "Pistachio Praline Cake", "price" => 16.00, "image" => "image/Pistachio Praline Cake.jpg"],
        ["name" => "Choclate Tiramisu", "price" => 16.00, "image" => "image/Choclate Tiramisu.jpg"],
        ["name" => "SC8. Peach Lychee Double Cheese Cake", "price" => 14.00, "image" => "image/SC8. Peach Lychee Double Cheese Cake.jpg"],
        ["name" => "SC2. Rainbow Marshmallow Slice Cake", "price" => 13.00, "image" => "image/SC2. Rainbow Marshmallow Slice Cake.jpg"],
        ["name" => "SC3. Chocolate Indulgence Slice Cake", "price" => 13.00, "image" => "image/SC3. Chocolate Indulgence Slice Cake.jpg"],
        ["name" => "SC4. Almond Tiramisu Slice Cake", "price" => 13.00, "image" => "image/SC4. Almond Tiramisu Slice Cake.jpg"],
        ["name" => "SC9. Lotus Butter Biscoff Cheese Slice Cake", "price" => 13.00, "image" => "image/SC9. Lotus Butter Biscoff Cheese Slice Cake.jpg"]
    ],
    "CROISSANT" => [
        ["name" => "CS1. Croissant Pistachio Nutty", "price" => 17.00, "image" => "image/CS1. Croissant Pistachio Nutty.jpg"],
        ["name" => "CS2. Croissant Chocolate Milky", "price" => 12.00, "image" => "image/CS2. Croissant Chocolate Milky.jpg"],
        ["name" => "CS3. Croissant Starwberry Creamy", "price" => 12.00, "image" => "image/CS3. Croissant Starwberry Creamy.jpg"],
        ["name" => "CS7. Choclate Ribbon Croissant", "price" =>17.00,"image"=>"image/CS7. Choclate Ribbon Croissant.jpg"]
    ],
    "DECORATION" => [
        ["name" => "BUNGA", "price" => 35.00, "image" => "images/placeholder.jpg"],
        ["name" => "DECORATION RM30", "price" => 30.00, "image" => "images/placeholder.jpg"],
        ["name" => "Decoration RM50", "price" => 50.00, "image" => "images/placeholder.jpg"],
        ["name" => "Decoration RM70", "price" => 70.00, "image" => "images/placeholder.jpg"]
	],
"JAMUAN RM 17" => [
    ["name" => "JAMUAN", "price" => 17.00, "image" => "images/placeholder.jpg"]
]
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Menu | Kafesta</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
<h1>Kafesta Delivery 🍴</h1>
<nav>
    <a href="index.php">Home</a>
    <a href="menu.php" class="active">Menu</a>
    <a href="cart.php">Cart (<?= $cart_count ?>)</a>
    <a href="logout.php">Logout</a>
</nav>
</header>

<h2>Our Menu</h2>
<?php foreach ($menu as $category => $items): ?>
    <h3 style="color:#145A32;"><?= $category ?></h3>
    <div class="menu-container">
        <?php foreach ($items as $item): ?>
        <div class="menu-item">
            <img src="<?= $item['image'] ?>" alt="<?= $item['name'] ?>" width="180" height="130"><br>
            <h4><?= $item['name'] ?></h4>
            <p>RM <?= $item['price'] ?>.00</p>
            <form method="post">
                <input type="hidden" name="food" value="<?= $item['name'] ?>">
                <input type="hidden" name="price" value="<?= $item['price'] ?>">
                <button type="submit" name="add">Add to Cart</button>
            </form>
        </div>
        <?php endforeach; ?>
    </div>
<?php endforeach; ?>

<footer><p>© 2025 Kafesta Delivery 💚</p></footer>
</body>
</html>
